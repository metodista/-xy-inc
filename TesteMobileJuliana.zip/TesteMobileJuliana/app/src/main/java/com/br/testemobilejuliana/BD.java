package com.br.testemobilejuliana;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

public class BD {
    SQLiteDatabase myDB;
    String tableName = "TB_FILMES";
    String dataBaseName = "BDTESTEMOBILEJULIANA";

    BD(Activity activity){
        try {
            myDB = activity.openOrCreateDatabase(dataBaseName, MODE_PRIVATE, null);

            String createTB_Usuario = "CREATE TABLE IF NOT EXISTS "
                    + tableName + " ("
                    +" id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    +" title VARCHAR NOT NULL, "
                    +" year VARCHAR NOT NULL, "
                    +" released VARCHAR NOT NULL, "
                    +" runtime VARCHAR NOT NULL, "
                    +" genre VARCHAR NOT NULL, "
                    +" actors VARCHAR NOT NULL, "
                    +" plot VARCHAR NOT NULL, "
                    +" imdbRating VARCHAR NOT NULL, "
                    +" poster VARCHAR NOT NULL "
                    +" );";


            /* Create a Table in the Database. */
            myDB.execSQL(createTB_Usuario);

            /* Insert data to a Table*/
            /*myDB.execSQL("INSERT INTO "
                    + tableNameUsuario
                    + " (matricula, nome, email)"
                    + " VALUES ('211', 'teste' , 'teste@teste.com');");*/
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public boolean selectFilme(String title){
        Cursor c = myDB.rawQuery("SELECT * FROM " + tableName + " WHERE title = '" + title + "'", null);
        if (c.moveToFirst()){
            do {
                c.close();
                //myDB.close();
                return true;
                // Passing values
                /*String column1 = c.getString(0);
                String column2 = c.getString(1);
                String column3 = c.getString(2);*/
                // Do something Here with values
            } while(c.moveToNext());
        }
        else{
            c.close();
            //myDB.close();
            return false;
        }
    }

    public List<Filme> selectFilmeTitle(String title){
        List<Filme> lista = new ArrayList<Filme>();
        Cursor c = myDB.rawQuery("SELECT * FROM " + tableName + " WHERE Title = '" + title + "'", null);
        if (c.moveToFirst()){
            do {
                Filme filme = new Filme(c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8),
                        c.getString(9));
                lista.add(filme);
                //c.close();
            } while(c.moveToNext());
        }
        c.close();
        return lista;
    }

    public List<Filme> selectFilmes(){
        List<Filme> lista = new ArrayList<Filme>();
        Cursor c = myDB.rawQuery("SELECT * FROM " + tableName, null);
        if (c.moveToFirst()){
            do {
                Filme filme = new Filme(c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8),
                        c.getString(9));
                lista.add(filme);
                //c.close();
            } while(c.moveToNext());
        }
        c.close();
        return lista;
    }

    public boolean inserirFilme(String title, String year, String released , String runtime , String genre , String actors , String plot , String imdbRating , String poster){
        try {

            myDB.execSQL("INSERT INTO "
                    + tableName
                    + " (title, year, released, runtime, genre, actors, plot, imdbRating, poster)"
                    + " VALUES ('" + title.replace("'", "") + "' , '" + year.replace("'", "") + "' , '" + released.replace("'", "") +
                    "' , '" + runtime.replace("'", "") + "' , '" + genre.replace("'", "") + "' , '" + actors.replace("'", "") +
                    "' , '" + plot.replace("'", "") + "' , '" + imdbRating.replace("'", "") + "' , '" + poster + "');");
            //myDB.close();
            return true;
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}