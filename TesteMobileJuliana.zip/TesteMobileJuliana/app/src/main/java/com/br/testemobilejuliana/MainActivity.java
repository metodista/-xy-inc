package com.br.testemobilejuliana;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    String nomeFilme;
    private ProgressDialog pDialog;
    JSONParser jParser = new JSONParser();
    private static String url = "http://www.omdbapi.com/";
    JSONArray filmeArray = null;
    static final String apikey = "d3a2d358";
    static int resultadoCadastro = 0;
    ListView lv_languages;


    ListAdapter list_adapter;
    String[] cardTitle;

    String[] cardYears;

    public static BD bd;

    String [] cardImages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 8)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                    .permitAll().build();
            StrictMode.setThreadPolicy(policy);
            //your codes here

        }

        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        init();
        lv_languages.setAdapter(list_adapter);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nomeFilme = "";
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Nome do filme");
                final EditText input = new EditText(MainActivity.this);
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                builder.setView(input);
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        nomeFilme = input.getText().toString();
                        if(!nomeFilme.equals("")){
                            //BD bd = new BD(MainActivity.this);
                            //if(!bd.selectFilme(nomeFilme)){
                                try {
                                    new NovoFilme(nomeFilme, bd).execute();

                                } catch (Exception e){
                                    System.out.println(e);
                                }
                            /*}
                            else{
                                Toast.makeText(MainActivity.this,"Filme já cadastrado!",
                                        Toast.LENGTH_SHORT).show();
                            }*/
                        }
                        else{
                            Toast.makeText(MainActivity.this,"Preencher o nome do filme!",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });
    }

    public Bitmap getBitmapFromURL(String src) {
        try {
            java.net.URL url = new java.net.URL(src);
            HttpURLConnection connection = (HttpURLConnection) url
                    .openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void layout(){

    }

    private void init() {
        bd = new BD(MainActivity.this);

        List<Filme> listaFilmes = bd.selectFilmes();
        if(listaFilmes.size()>0){
            cardTitle = new String[listaFilmes.size()];
            cardYears = new String[listaFilmes.size()];
            cardImages = new String[listaFilmes.size()];

            for(int i =0; i<listaFilmes.size(); i++){
                cardTitle[i] = listaFilmes.get(i).getTitle();
                cardYears[i] = listaFilmes.get(i).getYear();
                cardImages[i] = listaFilmes.get(i).getPoster();
            }
        }else{
            cardTitle = new String[] {"Nenhum filme cadastrado!"};
            cardYears = new String[] {""};
            cardImages = new String[]{""};
        }

        list_adapter = new ListAdapter(MainActivity.this, cardTitle, cardYears, cardImages);
        lv_languages = (ListView) findViewById(R.id.lv_languages);
    }

    public void result(){
        if(resultadoCadastro == 0){
            Toast.makeText(MainActivity.this,"Filme cadastrado com sucesso!",
                    Toast.LENGTH_SHORT).show();
        }
        else if(resultadoCadastro == 1){
            Toast.makeText(MainActivity.this,"Filme já cadastrado!",
                    Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(MainActivity.this,"Erro ao cadastrar o filme, tente novamente!",
                    Toast.LENGTH_SHORT).show();
        }
        init();
        lv_languages.setAdapter(list_adapter);
    }

    class NovoFilme extends AsyncTask<String, String, String> {
        private String name;
        private BD bd;
        /**
         * Before starting background thread Show Progress Dialog
         * */

        public NovoFilme (String name, BD bd){
            this.name = name;
            this.bd = bd;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Aguarde...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }

        /**
         * pega todos os usuarios via url
         * */
        protected String doInBackground(String... args) {
            // Building Parameters
            String pName = name;

            //BD bd = new BD(MainActivity.this);

            // Adicionado os parametros
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("t",pName));
            params.add(new BasicNameValuePair("apikey",apikey));

            // pega JSON string da URL
            // cria um novo cliente atraves do metodo POST
            JSONObject json = jParser.makeHttpRequest(url, "GET", params);

            try {
                // Operacao sem sucesso
                if(json == null){
                    resultadoCadastro = 2;
                }
                else {
                    if(!bd.selectFilme(json.getString("Title"))){
                        File f = null;
                    /*File path = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"mydir");
                    if(!path.exists()){
                        path.mkdir();
                    }*/
                        try{
                            Bitmap bPoster = getBitmapFromURL(json.getString("Poster"));


                            f = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), json.getString("Title") + ".png");
                            f.createNewFile();


                            Bitmap bitmap = bPoster;
                            ByteArrayOutputStream bos = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.PNG, 0 /*ignored for PNG*/, bos);
                            byte[] bitmapdata = bos.toByteArray();


                            FileOutputStream fos = new FileOutputStream(f);
                            fos.write(bitmapdata);
                            fos.flush();
                            fos.close();

                        }catch (Exception e){
                            e.printStackTrace();
                        }

                        if(bd.inserirFilme(json.getString("Title"), json.getString("Year"), json.getString("Released"), json.getString("Runtime"),
                                json.getString("Genre"), json.getString("Actors"), json.getString("Plot"),json.getString("imdbRating"),
                                f.getAbsolutePath().toString())){
                            resultadoCadastro = 0;
                        }
                        else{
                            resultadoCadastro = 2;
                        }
                    }
                    else{
                        resultadoCadastro = 1;
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        /**
         * After completing background task Dismiss the progress dialog
         * **/
        protected void onPostExecute(String file_url) {
            // fecha a barra de progresso
            pDialog.dismiss();
            // updating UI from Background Thread
            runOnUiThread(new Runnable() {
                public void run() {
                    result();
                }
            });

        }

    }
}
