package com.br.testemobilejuliana;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.List;

public class ListAdapter extends BaseAdapter{
    String [] result;
    String [] result_sector;
    Context context;
    String [] imageId;
    private static LayoutInflater inflater=null;

    public ListAdapter(MainActivity lista_candidatos, String[] prgmNameList, String[] prgmSectorList, String[] prgmImages) {
// TODO Auto-generated constructor stub
        result=prgmNameList;
        result_sector = prgmSectorList;
        context=lista_candidatos;
        imageId=prgmImages;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
// TODO Auto-generated method stub
        return result.length;
    }

    @Override
    public Object getItem(int position) {
// TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
// TODO Auto-generated method stub
        return position;
    }

    public class Holder
    {
        TextView text_name;
        TextView text_sector;
        ImageView im_language;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
// TODO Auto-generated method stub
        Holder holder=new Holder();
        View view;
        view = inflater.inflate(R.layout.list_item, null);

        holder.text_name =(TextView) view.findViewById(R.id.text_name);
        holder.text_sector =(TextView) view.findViewById(R.id.text_sector);
        holder.im_language=(ImageView) view.findViewById(R.id.im_language);

        holder.text_name.setText(result[position]);
        holder.text_sector.setText(result_sector[position]);
        if(!imageId[position].equals("")){
            Picasso.with(context).load(new File(imageId[position])).into(holder.im_language);
        }

        view.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                final Dialog dialog = new Dialog(context);

                dialog.setContentView(R.layout.dialog_confirm);

                final Button confirmar = (Button) dialog.findViewById(R.id.buttonConfirm);
                final TextView text_title = (TextView) dialog.findViewById(R.id.text_title);
                final TextView text_year = (TextView) dialog.findViewById(R.id.text_year);
                final TextView text_released = (TextView) dialog.findViewById(R.id.text_released);
                final TextView text_runtime = (TextView) dialog.findViewById(R.id.text_runtime);
                final TextView text_genre = (TextView) dialog.findViewById(R.id.text_genre);
                final TextView text_actors = (TextView) dialog.findViewById(R.id.text_actors);
                final TextView text_plot = (TextView) dialog.findViewById(R.id.text_plot);
                final TextView text_imdbRating = (TextView) dialog.findViewById(R.id.text_imdbRating);
                final ImageView image = (ImageView) dialog.findViewById(R.id.im_language);

                List<Filme> lista = MainActivity.bd.selectFilmeTitle(result[position]);

                text_title.setText(result[position]);
                text_year.setText(lista.get(0).getYear());
                text_released.setText("Released: " + lista.get(0).getReleased());
                text_runtime.setText("Runtime: " + lista.get(0).getRuntime());
                text_genre.setText("Genre: " + lista.get(0).getGenre());
                text_actors.setText("Actors: " + lista.get(0).getActors());
                text_plot.setText("Plot: " +lista.get(0).getPlot());
                text_imdbRating.setText("imdbRating: " + lista.get(0).getImdbRating());

                File imgFile = new  File(imageId[position]);

                if(imgFile.exists()){
                    Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                    image.setImageBitmap(myBitmap);
                }

                confirmar.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });
        return view;
    }

}